# paper-rcourse

[![status](http://jose.theoj.org/papers/1a083e69c49c15011f9404dfab9b1ec8/status.svg)](http://jose.theoj.org/papers/1a083e69c49c15011f9404dfab9b1ec8)

A paper describing our experiences initiating, developing, and teaching a course on data analysis with R in ecology.

Authors: please read [CONTRIBUTING.md](https://github.com/UofTCoders/paper-rcourse/blob/master/CONTRIBUTING.md) before starting work.
